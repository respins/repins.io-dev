<?php

namespace ase\RespinsBaseFunctions;

class RespinsBaseFunctions
{
}
